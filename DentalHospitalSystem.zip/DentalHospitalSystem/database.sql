-- ========================================
-- 口腔医院管理系统数据库初始化脚本
-- ========================================

-- 创建数据库
CREATE DATABASE IF NOT EXISTS dental_hospital 
DEFAULT CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE dental_hospital;

-- 用户表
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL COMMENT '用户名',
    password VARCHAR(100) NOT NULL COMMENT '密码',
    real_name VARCHAR(50) NOT NULL COMMENT '真实姓名',
    phone VARCHAR(20) COMMENT '手机号',
    email VARCHAR(100) COMMENT '邮箱',
    id_card VARCHAR(18) COMMENT '身份证号',
    role ENUM('user', 'admin', 'doctor') NOT NULL DEFAULT 'user' COMMENT '角色',
    status TINYINT DEFAULT 1 COMMENT '状态：1正常 0禁用',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 储值卡表
CREATE TABLE IF NOT EXISTS value_cards (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    card_number VARCHAR(50) UNIQUE NOT NULL COMMENT '卡号',
    balance DECIMAL(10,2) DEFAULT 0.00 COMMENT '余额',
    total_recharge DECIMAL(10,2) DEFAULT 0.00 COMMENT '累计充值',
    status TINYINT DEFAULT 1 COMMENT '状态：1正常 0冻结',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='储值卡表';

-- 预约挂号表
CREATE TABLE IF NOT EXISTS appointments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL COMMENT '用户ID',
    doctor_id INT COMMENT '医生ID',
    appointment_date DATE NOT NULL COMMENT '预约日期',
    appointment_time VARCHAR(20) NOT NULL COMMENT '预约时段',
    department VARCHAR(50) COMMENT '科室',
    symptoms TEXT COMMENT '症状描述',
    status ENUM('pending', 'confirmed', 'completed', 'cancelled') DEFAULT 'pending' COMMENT '状态',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='预约挂号表';

-- 就诊记录表
CREATE TABLE IF NOT EXISTS medical_records (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL COMMENT '患者ID',
    doctor_id INT NOT NULL COMMENT '医生ID',
    appointment_id INT COMMENT '预约ID',
    diagnosis TEXT COMMENT '诊断结果',
    treatment TEXT COMMENT '治疗方案',
    prescription TEXT COMMENT '处方',
    cost DECIMAL(10,2) COMMENT '费用',
    visit_date DATETIME NOT NULL COMMENT '就诊时间',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='就诊记录表';

-- 医疗用品表
CREATE TABLE IF NOT EXISTS medical_supplies (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL COMMENT '名称',
    category VARCHAR(50) COMMENT '分类',
    specification VARCHAR(100) COMMENT '规格',
    unit VARCHAR(20) COMMENT '单位',
    stock_quantity INT DEFAULT 0 COMMENT '库存数量',
    min_stock INT DEFAULT 10 COMMENT '最小库存',
    unit_price DECIMAL(10,2) COMMENT '单价',
    supplier VARCHAR(100) COMMENT '供应商',
    status TINYINT DEFAULT 1 COMMENT '状态',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='医疗用品表';

-- 医生排班表
CREATE TABLE IF NOT EXISTS doctor_schedules (
    id INT PRIMARY KEY AUTO_INCREMENT,
    doctor_id INT NOT NULL,
    work_date DATE NOT NULL COMMENT '排班日期',
    shift_type ENUM('morning', 'afternoon', 'evening') NOT NULL COMMENT '班次',
    max_appointments INT DEFAULT 20 COMMENT '最大预约数',
    booked_count INT DEFAULT 0 COMMENT '已预约数',
    status TINYINT DEFAULT 1 COMMENT '状态：1可预约 0不可预约',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_schedule (doctor_id, work_date, shift_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='医生排班表';


-- 1. 储值卡交易记录表
CREATE TABLE IF NOT EXISTS card_transactions (
                                                 id INT PRIMARY KEY AUTO_INCREMENT,
                                                 card_id INT NOT NULL COMMENT '储值卡ID',
                                                 transaction_type ENUM('recharge', 'consume') NOT NULL COMMENT '交易类型：充值/消费',
    amount DECIMAL(10,2) NOT NULL COMMENT '交易金额',
    balance_before DECIMAL(10,2) NOT NULL COMMENT '交易前余额',
    balance_after DECIMAL(10,2) NOT NULL COMMENT '交易后余额',
    description VARCHAR(200) COMMENT '交易描述',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '交易时间',
    FOREIGN KEY (card_id) REFERENCES value_cards(id) ON DELETE CASCADE,
    INDEX idx_card_id (card_id),
    INDEX idx_created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='储值卡交易记录表';

-- 2. 收藏表
CREATE TABLE IF NOT EXISTS favorites (
                                         id INT PRIMARY KEY AUTO_INCREMENT,
                                         user_id INT NOT NULL COMMENT '用户ID',
                                         doctor_id INT NOT NULL COMMENT '医生ID',
                                         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '收藏时间',
                                         FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_favorite (user_id, doctor_id),
    INDEX idx_user_id (user_id),
    INDEX idx_doctor_id (doctor_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='收藏表';

-- 3. 消息表
CREATE TABLE IF NOT EXISTS messages (
                                        id INT PRIMARY KEY AUTO_INCREMENT,
                                        user_id INT NOT NULL COMMENT '用户ID',
                                        title VARCHAR(200) NOT NULL COMMENT '消息标题',
    content TEXT COMMENT '消息内容',
    type VARCHAR(50) DEFAULT 'system' COMMENT '消息类型：system/appointment/notice',
    is_read TINYINT DEFAULT 0 COMMENT '是否已读：0未读 1已读',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_is_read (is_read),
    INDEX idx_created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息表';

-- ========================================
-- 插入测试数据
-- ========================================

-- 插入管理员
INSERT INTO users (username, password, real_name, phone, role) VALUES 
('admin', 'admin123', '系统管理员', '13800138000', 'admin');

-- 插入医生
INSERT INTO users (username, password, real_name, phone, role) VALUES 
('doctor1', 'doctor123', '张医生', '13800138001', 'doctor'),
('doctor2', 'doctor123', '李医生', '13800138002', 'doctor'),
('doctor3', 'doctor123', '王医生', '13800138003', 'doctor');

-- 插入普通用户
INSERT INTO users (username, password, real_name, phone, role) VALUES 
('user1', 'user123', '王小明', '13800138010', 'user'),
('user2', 'user123', '李小红', '13800138011', 'user'),
('user3', 'user123', '张三', '13800138012', 'user');

-- 插入医疗用品
INSERT INTO medical_supplies (name, category, specification, unit, stock_quantity, min_stock, unit_price, supplier) VALUES 
('一次性口罩', '防护用品', '50只/盒', '盒', 100, 20, 15.00, '医疗器械公司A'),
('一次性手套', '防护用品', '100只/盒', '盒', 80, 15, 25.00, '医疗器械公司A'),
('消毒液', '消毒用品', '500ml/瓶', '瓶', 50, 10, 30.00, '医疗用品公司B'),
('牙科钻头', '器械', '标准型', '支', 50, 10, 120.00, '牙科设备公司C'),
('牙科填充材料', '材料', '复合树脂', '支', 30, 5, 180.00, '牙科材料公司D');

-- 插入医生排班（示例）
INSERT INTO doctor_schedules (doctor_id, work_date, shift_type, max_appointments) VALUES
(2, '2024-12-10', 'morning', 15),
(2, '2024-12-10', 'afternoon', 15),
(3, '2024-12-10', 'morning', 15),
(3, '2024-12-11', 'afternoon', 15),
(4, '2024-12-10', 'morning', 15),
(4, '2024-12-10', 'afternoon', 15);

-- 为测试用户添加一些消息
INSERT INTO messages (user_id, title, content, type) VALUES
(5, '欢迎使用口腔医院管理系统', '您好!欢迎注册并使用我们的系统。如有任何问题,请随时联系我们。', 'system'),
(5, '预约提醒', '您的预约时间即将到来,请准时就诊。', 'appointment'),
(6, '系统通知', '系统将于本周末进行维护,届时可能会短暂无法访问。', 'system');

-- 查看创建的表
SHOW TABLES;

-- 查看用户数据
SELECT id, username, real_name, role FROM users;
