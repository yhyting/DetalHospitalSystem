<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.User" %>
<%
    // 如果用户已登录，跳转到对应的dashboard
    User user = (User) session.getAttribute("user");
    if (user != null) {
        String role = user.getRole();
        if ("admin".equals(role)) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard.jsp");
        } else if ("doctor".equals(role)) {
            response.sendRedirect(request.getContextPath() + "/doctor/dashboard.jsp");
        } else {
            response.sendRedirect(request.getContextPath() + "/user/dashboard.jsp");
        }
        return;
    }
    // 未登录则跳转到登录页
    response.sendRedirect(request.getContextPath() + "/login.jsp");
%>
