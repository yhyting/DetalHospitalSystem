<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.User" %>
<%
    User user = (User) session.getAttribute("user");
    if (user == null || !"doctor".equals(user.getRole())) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>医生工作台 - 口腔医院管理系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: #f5f5f5;
        }
        .header {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
            padding: 20px 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header h1 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        .header p {
            font-size: 14px;
            opacity: 0.9;
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .welcome-card {
            background: white;
            border-radius: 10px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .welcome-card h2 {
            color: #333;
            margin-bottom: 10px;
        }
        .welcome-card p {
            color: #666;
            font-size: 14px;
        }
        .menu-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        .menu-item {
            background: white;
            border-radius: 10px;
            padding: 30px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
            text-decoration: none;
            color: inherit;
            display: block;
        }
        .menu-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .menu-item .icon {
            font-size: 48px;
            margin-bottom: 15px;
        }
        .menu-item h3 {
            color: #333;
            margin-bottom: 10px;
            font-size: 18px;
        }
        .menu-item p {
            color: #666;
            font-size: 14px;
        }
        .logout-btn {
            position: fixed;
            top: 20px;
            right: 40px;
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.3s;
        }
        .logout-btn:hover {
            background: rgba(255,255,255,0.3);
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🦷 口腔医院管理系统</h1>
        <p>医生工作台</p>
        <a href="${pageContext.request.contextPath}/logout" class="logout-btn">退出登录</a>
    </div>
    
    <div class="container">
        <div class="welcome-card">
            <h2>欢迎，<%= user.getRealName() != null ? user.getRealName() : user.getUsername() %> 医生！</h2>
            <p>您好，这是您的医生工作台。您可以在这里管理预约、查看病历、开具处方等。</p>
        </div>
        
        <div class="menu-grid">
            <a href="${pageContext.request.contextPath}/appointment?action=list" class="menu-item">
                <div class="icon">📅</div>
                <h3>预约管理</h3>
                <p>查看和处理患者预约</p>
            </a>
            
            <a href="${pageContext.request.contextPath}/doctor/schedule.jsp" class="menu-item">
                <div class="icon">🕐</div>
                <h3>排班管理</h3>
                <p>设置和查看工作排班</p>
            </a>
            
            <a href="${pageContext.request.contextPath}/doctor/records.jsp" class="menu-item">
                <div class="icon">📋</div>
                <h3>病例管理</h3>
                <p>管理患者病历信息</p>
            </a>
            
            <a href="${pageContext.request.contextPath}/doctor/prescription.jsp" class="menu-item">
                <div class="icon">💊</div>
                <h3>处方开具</h3>
                <p>为患者开具处方</p>
            </a>
            
            <a href="${pageContext.request.contextPath}/doctor/images.jsp" class="menu-item">
                <div class="icon">🔬</div>
                <h3>诊疗影像</h3>
                <p>查看和管理诊疗影像</p>
            </a>
            
            <a href="${pageContext.request.contextPath}/doctor/profile.jsp" class="menu-item">
                <div class="icon">👤</div>
                <h3>个人信息</h3>
                <p>查看和修改个人信息</p>
            </a>
        </div>
    </div>
</body>
</html>
