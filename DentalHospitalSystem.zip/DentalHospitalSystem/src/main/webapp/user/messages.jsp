<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.User" %>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.Message" %>
<%@ page import="com.yhyting.dentalhospitalsystem.dao.MessageDAO" %>
<%@ page import="java.util.List" %>
<%
    User currentUser = (User) session.getAttribute("user");
    if (currentUser == null || !"user".equals(currentUser.getRole())) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }

    MessageDAO messageDAO = new MessageDAO();
    List<Message> messages = messageDAO.findByUserId(currentUser.getId());
    int unreadCount = messageDAO.getUnreadCount(currentUser.getId());
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>消息中心 - 口腔医院管理系统</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        .header {
            background: white;
            padding: 20px 30px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            color: #333;
            font-size: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .unread-badge {
            background: #ff4757;
            color: white;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 14px;
        }

        .header .actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 14px;
        }

        .btn:hover {
            background: #764ba2;
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: #95a5a6;
        }

        .btn-secondary:hover {
            background: #7f8c8d;
        }

        .content {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .stats-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .stat-card h3 {
            font-size: 16px;
            margin-bottom: 10px;
            opacity: 0.9;
        }

        .stat-card .number {
            font-size: 32px;
            font-weight: bold;
        }

        .filter-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 10px;
        }

        .filter-tab {
            padding: 8px 16px;
            background: none;
            border: none;
            color: #666;
            cursor: pointer;
            border-radius: 5px;
            transition: all 0.3s;
        }

        .filter-tab.active {
            background: #667eea;
            color: white;
        }

        .messages-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .message-item {
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 20px;
            transition: all 0.3s;
            position: relative;
        }

        .message-item.unread {
            background: #f8f9ff;
            border-left: 4px solid #667eea;
        }

        .message-item:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transform: translateX(5px);
        }

        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 10px;
        }

        .message-title {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .message-type-badge {
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 12px;
            color: white;
        }

        .type-system { background: #3498db; }
        .type-appointment { background: #e67e22; }
        .type-notice { background: #9b59b6; }

        .message-content {
            color: #666;
            line-height: 1.6;
            margin-bottom: 10px;
        }

        .message-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: #999;
            font-size: 13px;
        }

        .message-actions {
            display: flex;
            gap: 10px;
        }

        .action-icon {
            background: none;
            border: none;
            cursor: pointer;
            font-size: 18px;
            transition: all 0.3s;
            padding: 5px;
        }

        .action-icon:hover {
            transform: scale(1.2);
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }

        .empty-state .icon {
            font-size: 64px;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .empty-state h2 {
            color: #666;
            margin-bottom: 10px;
        }

        .empty-state p {
            color: #999;
        }

        .delete-icon { color: #ff4757; }
        .mark-read-icon { color: #2ecc71; }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 15px;
            }

            .filter-tabs {
                flex-wrap: wrap;
            }

            .message-header {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>
            💌 消息中心
            <% if (unreadCount > 0) { %>
            <span class="unread-badge"><%= unreadCount %> 条未读</span>
            <% } %>
        </h1>
        <div class="actions">
            <button class="btn" onclick="markAllAsRead()">全部已读</button>
            <a href="${pageContext.request.contextPath}/user/dashboard.jsp" class="btn btn-secondary">返回首页</a>
        </div>
    </div>

    <div class="content">
        <div class="stats-row">
            <div class="stat-card">
                <h3>总消息数</h3>
                <div class="number"><%= messages.size() %></div>
            </div>
            <div class="stat-card">
                <h3>未读消息</h3>
                <div class="number"><%= unreadCount %></div>
            </div>
        </div>

        <div class="filter-tabs">
            <button class="filter-tab active" data-filter="all">全部</button>
            <button class="filter-tab" data-filter="unread">未读</button>
            <button class="filter-tab" data-filter="system">系统</button>
            <button class="filter-tab" data-filter="appointment">预约</button>
            <button class="filter-tab" data-filter="notice">通知</button>
        </div>

        <% if (messages != null && !messages.isEmpty()) { %>
        <div class="messages-list">
            <% for (Message message : messages) { %>
            <div class="message-item <%= message.getIsRead() == 0 ? "unread" : "" %>"
                 data-id="<%= message.getId() %>"
                 data-type="<%= message.getType() %>"
                 data-read="<%= message.getIsRead() %>">

                <div class="message-header">
                    <div class="message-title">
                        <%= message.getTitle() %>
                        <span class="message-type-badge type-<%= message.getType() %>">
                                        <%= getTypeLabel(message.getType()) %>
                                    </span>
                    </div>
                </div>

                <div class="message-content">
                    <%= message.getContent() %>
                </div>

                <div class="message-footer">
                                <span>
                                    <%= new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(message.getCreatedAt()) %>
                                </span>
                    <div class="message-actions">
                        <% if (message.getIsRead() == 0) { %>
                        <button class="action-icon mark-read-icon"
                                onclick="markAsRead(<%= message.getId() %>)"
                                title="标记为已读">
                            ✓
                        </button>
                        <% } %>
                        <button class="action-icon delete-icon"
                                onclick="deleteMessage(<%= message.getId() %>)"
                                title="删除">
                            🗑️
                        </button>
                    </div>
                </div>
            </div>
            <% } %>
        </div>
        <% } else { %>
        <div class="empty-state">
            <div class="icon">📭</div>
            <h2>暂无消息</h2>
            <p>您目前没有任何消息</p>
        </div>
        <% } %>
    </div>
</div>

<script>
    // 过滤功能
    document.querySelectorAll('.filter-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            // 更新激活状态
            document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');

            const filter = this.dataset.filter;
            const messages = document.querySelectorAll('.message-item');

            messages.forEach(message => {
                const type = message.dataset.type;
                const isRead = message.dataset.read;

                if (filter === 'all') {
                    message.style.display = 'block';
                } else if (filter === 'unread') {
                    message.style.display = isRead === '0' ? 'block' : 'none';
                } else {
                    message.style.display = type === filter ? 'block' : 'none';
                }
            });
        });
    });

    // 标记单个消息为已读
    function markAsRead(messageId) {
        fetch('${pageContext.request.contextPath}/message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=markRead&messageId=' + messageId
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const messageItem = document.querySelector(`[data-id="${messageId}"]`);
                    messageItem.classList.remove('unread');
                    messageItem.dataset.read = '1';

                    // 移除已读按钮
                    const markReadBtn = messageItem.querySelector('.mark-read-icon');
                    if (markReadBtn) {
                        markReadBtn.remove();
                    }

                    // 更新未读数量
                    location.reload();
                } else {
                    alert('操作失败: ' + (data.message || '未知错误'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('操作失败,请稍后重试');
            });
    }

    // 标记所有消息为已读
    function markAllAsRead() {
        if (!confirm('确定要将所有消息标记为已读吗?')) {
            return;
        }

        fetch('${pageContext.request.contextPath}/message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=markAllRead'
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('所有消息已标记为已读!');
                    location.reload();
                } else {
                    alert('操作失败: ' + (data.message || '未知错误'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('操作失败,请稍后重试');
            });
    }

    // 删除消息
    function deleteMessage(messageId) {
        if (!confirm('确定要删除这条消息吗?')) {
            return;
        }

        fetch('${pageContext.request.contextPath}/message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=delete&messageId=' + messageId
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const messageItem = document.querySelector(`[data-id="${messageId}"]`);
                    messageItem.style.opacity = '0';
                    messageItem.style.transform = 'translateX(-20px)';

                    setTimeout(() => {
                        messageItem.remove();

                        // 检查是否还有消息
                        const messagesList = document.querySelector('.messages-list');
                        if (messagesList && messagesList.children.length === 0) {
                            location.reload();
                        }
                    }, 300);
                } else {
                    alert('操作失败: ' + (data.message || '未知错误'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('操作失败,请稍后重试');
            });
    }
</script>
</body>
</html>

<%!
    private String getTypeLabel(String type) {
        switch (type) {
            case "system": return "系统";
            case "appointment": return "预约";
            case "notice": return "通知";
            default: return "其他";
        }
    }
%>