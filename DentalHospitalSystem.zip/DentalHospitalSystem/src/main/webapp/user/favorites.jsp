<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.User" %>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.Favorite" %>
<%@ page import="com.yhyting.dentalhospitalsystem.dao.FavoriteDAO" %>
<%@ page import="com.yhyting.dentalhospitalsystem.dao.UserDAO" %>
<%@ page import="java.util.List" %>
<%
    User currentUser = (User) session.getAttribute("user");
    if (currentUser == null || !"user".equals(currentUser.getRole())) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }

    FavoriteDAO favoriteDAO = new FavoriteDAO();
    UserDAO userDAO = new UserDAO();
    List<Favorite> favorites = favoriteDAO.findByUserId(currentUser.getId());
    List<User> doctors = userDAO.findAll("doctor"); // 获取所有医生
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>我的收藏 - 口腔医院管理系统</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            background: white;
            padding: 20px 30px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            color: #333;
            font-size: 24px;
        }

        .header .user-info {
            color: #666;
        }

        .back-btn {
            display: inline-block;
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 5px;
            transition: all 0.3s;
            cursor: pointer;
            margin-left: 10px;
        }

        .back-btn:hover {
            background: #764ba2;
            transform: translateY(-2px);
        }

        .add-favorite-btn {
            background: #2ecc71;
            font-size: 18px;
            padding: 10px 25px;
        }

        .add-favorite-btn:hover {
            background: #27ae60;
        }

        .content {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .favorites-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .favorite-card {
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 20px;
            transition: all 0.3s;
            position: relative;
            cursor: pointer;
        }

        .favorite-card:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transform: translateY(-5px);
        }

        .doctor-avatar {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            color: white;
            margin: 0 auto 15px;
        }

        .doctor-name {
            font-size: 20px;
            font-weight: bold;
            color: #333;
            text-align: center;
            margin-bottom: 10px;
        }

        .doctor-info {
            color: #666;
            font-size: 14px;
            margin: 8px 0;
            display: flex;
            align-items: center;
        }

        .doctor-info .icon {
            margin-right: 8px;
            color: #667eea;
        }

        .favorite-date {
            color: #999;
            font-size: 12px;
            text-align: center;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #f0f0f0;
        }

        .star-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 24px;
            transition: all 0.3s;
            z-index: 10;
        }

        .star-btn.active {
            color: #ffd700;
        }

        .star-btn:not(.active) {
            color: #ddd;
        }

        .star-btn:hover {
            transform: scale(1.2);
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }

        .empty-state .icon {
            font-size: 64px;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .empty-state h2 {
            color: #666;
            margin-bottom: 10px;
        }

        .empty-state p {
            color: #999;
            margin-bottom: 30px;
        }

        .action-btn {
            display: inline-block;
            padding: 12px 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 5px;
            transition: all 0.3s;
            cursor: pointer;
            font-size: 16px;
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }

        .stats {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }

        .stats h3 {
            font-size: 18px;
            margin-bottom: 10px;
        }

        .stats .count {
            font-size: 36px;
            font-weight: bold;
        }

        /* 医生选择模态窗口 */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            overflow-y: auto;
        }

        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 10px;
            max-width: 900px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            position: relative;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .modal-header h2 {
            color: #333;
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 28px;
            cursor: pointer;
            color: #999;
            transition: all 0.3s;
        }

        .close-btn:hover {
            color: #333;
            transform: rotate(90deg);
        }

        .doctors-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }

        .doctor-card {
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            padding: 20px;
            transition: all 0.3s;
            position: relative;
            cursor: pointer;
        }

        .doctor-card:hover {
            border-color: #667eea;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.2);
        }

        .doctor-card.favorited {
            border-color: #ffd700;
            background: #fffef8;
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 15px;
            }

            .favorites-grid, .doctors-grid {
                grid-template-columns: 1fr;
            }

            .modal-content {
                width: 95%;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>⭐ 我的收藏</h1>
        <div>
            <span class="user-info">欢迎, <%= currentUser.getRealName() %></span>
            <% if (favorites != null && !favorites.isEmpty()) { %>
            <button class="back-btn add-favorite-btn" onclick="openDoctorModal()">+ 添加收藏</button>
            <% } %>
            <a href="${pageContext.request.contextPath}/user/dashboard.jsp" class="back-btn">返回首页</a>
        </div>
    </div>

    <div class="content">
        <% if (favorites != null && !favorites.isEmpty()) { %>
        <div class="stats">
            <h3>收藏统计</h3>
            <div class="count"><%= favorites.size() %></div>
            <p>位收藏的医生</p>
        </div>

        <div class="favorites-grid">
            <% for (Favorite favorite : favorites) { %>
            <div class="favorite-card"
                 id="favorite-<%= favorite.getId() %>"
                 onclick="goToAppointment(<%= favorite.getDoctorId() %>)">

                <button class="star-btn active"
                        onclick="event.stopPropagation(); toggleFavorite(<%= favorite.getDoctorId() %>, this)"
                        title="取消收藏">
                    ★
                </button>

                <div class="doctor-avatar">
                    👨‍⚕️
                </div>

                <div class="doctor-name">
                    <%= favorite.getDoctorName() != null ? favorite.getDoctorName() : "医生" %>
                </div>

                <% if (favorite.getDoctorPhone() != null && !favorite.getDoctorPhone().isEmpty()) { %>
                <div class="doctor-info">
                    <span class="icon">📞</span>
                    <%= favorite.getDoctorPhone() %>
                </div>
                <% } %>

                <% if (favorite.getDoctorEmail() != null && !favorite.getDoctorEmail().isEmpty()) { %>
                <div class="doctor-info">
                    <span class="icon">✉️</span>
                    <%= favorite.getDoctorEmail() %>
                </div>
                <% } %>

                <div class="favorite-date">
                    收藏于: <%= new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(favorite.getCreatedAt()) %>
                </div>
            </div>
            <% } %>
        </div>
        <% } else { %>
        <div class="empty-state">
            <div class="icon">💝</div>
            <h2>还没有收藏任何医生</h2>
            <p>快去收藏您喜欢的医生吧!</p>
            <button onclick="openDoctorModal()" class="action-btn">去收藏</button>
        </div>
        <% } %>
    </div>
</div>

<!-- 医生选择模态窗口 -->
<div id="doctorModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>选择要收藏的医生</h2>
            <button class="close-btn" onclick="closeDoctorModal()">&times;</button>
        </div>

        <div class="doctors-grid">
            <%
                // 构建已收藏医生的ID集合
                java.util.Set<Integer> favoritedDoctorIds = new java.util.HashSet<>();
                if (favorites != null) {
                    for (Favorite fav : favorites) {
                        favoritedDoctorIds.add(fav.getDoctorId());
                    }
                }

                for (User doctor : doctors) {
                    boolean isFavorited = favoritedDoctorIds.contains(doctor.getId());
            %>
            <div class="doctor-card <%= isFavorited ? "favorited" : "" %>"
                 id="doctor-card-<%= doctor.getId() %>">

                <button class="star-btn <%= isFavorited ? "active" : "" %>"
                        onclick="toggleFavorite(<%= doctor.getId() %>, this)"
                        title="<%= isFavorited ? "取消收藏" : "添加收藏" %>">
                    ★
                </button>

                <div class="doctor-avatar">
                    👨‍⚕️
                </div>

                <div class="doctor-name">
                    <%= doctor.getRealName() %>
                </div>

                <% if (doctor.getPhone() != null && !doctor.getPhone().isEmpty()) { %>
                <div class="doctor-info">
                    <span class="icon">📞</span>
                    <%= doctor.getPhone() %>
                </div>
                <% } %>

                <% if (doctor.getEmail() != null && !doctor.getEmail().isEmpty()) { %>
                <div class="doctor-info">
                    <span class="icon">✉️</span>
                    <%= doctor.getEmail() %>
                </div>
                <% } %>
            </div>
            <% } %>
        </div>
    </div>
</div>

<script>
    // 打开医生选择模态窗口
    function openDoctorModal() {
        document.getElementById('doctorModal').classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    // 关闭医生选择模态窗口
    function closeDoctorModal() {
        document.getElementById('doctorModal').classList.remove('active');
        document.body.style.overflow = 'auto';
    }

    // 点击模态窗口外部关闭
    document.getElementById('doctorModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeDoctorModal();
        }
    });

    // 切换收藏状态
    function toggleFavorite(doctorId, button) {
        const isActive = button.classList.contains('active');
        const action = isActive ? 'remove' : 'add';

        fetch('${pageContext.request.contextPath}/favorite', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=' + action + '&doctorId=' + doctorId
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // 更新UI
                    if (isActive) {
                        // 取消收藏
                        button.classList.remove('active');
                        button.title = '添加收藏';

                        // 如果在收藏列表中,移除卡片
                        const favoriteCard = document.getElementById('favorite-' + doctorId);
                        if (favoriteCard) {
                            favoriteCard.style.opacity = '0';
                            favoriteCard.style.transform = 'scale(0.8)';
                            setTimeout(() => {
                                location.reload(); // 重新加载页面以更新统计
                            }, 300);
                        }

                        // 在模态窗口中更新卡片样式
                        const doctorCard = document.getElementById('doctor-card-' + doctorId);
                        if (doctorCard) {
                            doctorCard.classList.remove('favorited');
                        }
                    } else {
                        // 添加收藏
                        button.classList.add('active');
                        button.title = '取消收藏';

                        // 在模态窗口中更新卡片样式
                        const doctorCard = document.getElementById('doctor-card-' + doctorId);
                        if (doctorCard) {
                            doctorCard.classList.add('favorited');
                        }

                        // 提示成功并询问是否重新加载
                        if (confirm('收藏成功!是否刷新页面查看?')) {
                            location.reload();
                        }
                    }
                } else {
                    alert(data.message || '操作失败,请稍后重试');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('操作失败,请稍后重试');
            });
    }

    // 跳转到预约页面并自动选择医生
    function goToAppointment(doctorId) {
        window.location.href = '${pageContext.request.contextPath}/user/add-appointment.jsp?doctorId=' + doctorId;
    }
</script>
</body>
</html>
