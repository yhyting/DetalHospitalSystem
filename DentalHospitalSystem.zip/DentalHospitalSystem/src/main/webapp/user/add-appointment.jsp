<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.User" %>
<%@ page import="com.yhyting.dentalhospitalsystem.dao.UserDAO" %>
<%@ page import="java.util.List" %>
<%
    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }

    // 获取预选的医生ID
    String preselectedDoctorId = request.getParameter("doctorId");

    // 获取所有医生列表
    UserDAO userDAO = new UserDAO();
    List<User> doctors = userDAO.findAll("doctor");
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>预约挂号 - 口腔医院管理系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: #f5f5f5;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container {
            max-width: 800px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .form-card {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }
        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-right: 10px;
            transition: all 0.3s;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-primary:hover {
            background: #764ba2;
            transform: translateY(-2px);
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
            text-decoration: none;
            display: inline-block;
        }
        .btn-secondary:hover {
            background: #5a6268;
        }
        .alert {
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .alert-error {
            background: #fee;
            color: #c33;
            border: 1px solid #fcc;
        }
        .alert-info {
            background: #e7f3ff;
            color: #0066cc;
            border: 1px solid #b3d9ff;
        }
        .doctor-selection-hint {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
    </style>
</head>
<body>
<div class="header">
    <h1>📋 预约挂号</h1>
</div>

<div class="container">
    <div class="form-card">
        <h2 style="margin-bottom: 20px;">填写预约信息</h2>

        <% if (request.getAttribute("error") != null) { %>
        <div class="alert alert-error">
            <%= request.getAttribute("error") %>
        </div>
        <% } %>

        <% if (preselectedDoctorId != null && !preselectedDoctorId.isEmpty()) { %>
        <div class="alert alert-info">
            ✓ 已自动选择您收藏的医生
        </div>
        <% } %>

        <form action="${pageContext.request.contextPath}/appointment" method="post">
            <input type="hidden" name="action" value="add">

            <!-- 医生选择 -->
            <div class="form-group">
                <label for="doctorId">选择医生 (可选)</label>
                <select id="doctorId" name="doctorId">
                    <option value="">不指定医生</option>
                    <% for (User doctor : doctors) { %>
                    <option value="<%= doctor.getId() %>"
                            <%= (preselectedDoctorId != null && preselectedDoctorId.equals(String.valueOf(doctor.getId()))) ? "selected" : "" %>>
                        <%= doctor.getRealName() %><%= doctor.getPhone() != null ? " (" + doctor.getPhone() + ")" : "" %>
                    </option>
                    <% } %>
                </select>
                <div class="doctor-selection-hint">
                    如不选择医生,系统将自动为您安排
                </div>
            </div>

            <div class="form-group">
                <label for="appointmentDate">预约日期 *</label>
                <input type="date" id="appointmentDate" name="appointmentDate" required
                       min="<%= new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date()) %>">
            </div>

            <div class="form-group">
                <label for="appointmentTime">预约时间 *</label>
                <select id="appointmentTime" name="appointmentTime" required>
                    <option value="">请选择时间段</option>
                    <option value="08:00-09:00">08:00-09:00</option>
                    <option value="09:00-10:00">09:00-10:00</option>
                    <option value="10:00-11:00">10:00-11:00</option>
                    <option value="11:00-12:00">11:00-12:00</option>
                    <option value="14:00-15:00">14:00-15:00</option>
                    <option value="15:00-16:00">15:00-16:00</option>
                    <option value="16:00-17:00">16:00-17:00</option>
                </select>
            </div>

            <div class="form-group">
                <label for="department">就诊科室 *</label>
                <select id="department" name="department" required>
                    <option value="">请选择科室</option>
                    <option value="牙体牙髓科">牙体牙髓科</option>
                    <option value="牙周科">牙周科</option>
                    <option value="口腔修复科">口腔修复科</option>
                    <option value="口腔正畸科">口腔正畸科</option>
                    <option value="口腔种植科">口腔种植科</option>
                    <option value="儿童口腔科">儿童口腔科</option>
                    <option value="口腔颌面外科">口腔颌面外科</option>
                </select>
            </div>

            <div class="form-group">
                <label for="symptoms">症状描述 *</label>
                <textarea id="symptoms" name="symptoms" required
                          placeholder="请简要描述您的症状..."></textarea>
            </div>

            <div>
                <button type="submit" class="btn btn-primary">提交预约</button>
                <a href="${pageContext.request.contextPath}/appointment?action=list"
                   class="btn btn-secondary">取消</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>