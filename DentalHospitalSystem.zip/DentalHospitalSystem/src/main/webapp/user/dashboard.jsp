<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.User" %>
<%
    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户中心 - 口腔医院管理系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: #f5f5f5;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header h1 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        .header p {
            font-size: 14px;
            opacity: 0.9;
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .welcome-card {
            background: white;
            border-radius: 10px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .welcome-card h2 {
            color: #333;
            margin-bottom: 10px;
        }
        .welcome-card p {
            color: #666;
            font-size: 14px;
        }
        .menu-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .menu-item {
            background: white;
            border-radius: 10px;
            padding: 30px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
            text-decoration: none;
            color: inherit;
            display: block;
        }
        .menu-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .menu-item .icon {
            font-size: 48px;
            margin-bottom: 15px;
        }
        .menu-item h3 {
            color: #333;
            margin-bottom: 10px;
            font-size: 18px;
        }
        .menu-item p {
            color: #666;
            font-size: 14px;
        }
        .logout-btn {
            position: fixed;
            top: 20px;
            right: 40px;
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.3s;
        }
        .logout-btn:hover {
            background: rgba(255,255,255,0.3);
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🦷 口腔医院管理系统</h1>
        <p>用户中心</p>
        <a href="${pageContext.request.contextPath}/logout" class="logout-btn">退出登录</a>
    </div>
    
    <div class="container">
        <div class="welcome-card">
            <h2>欢迎，<%= user.getRealName() != null ? user.getRealName() : user.getUsername() %>！</h2>
            <p>您好，这是您的个人中心。您可以在这里管理您的预约、查看就诊记录等。</p>
        </div>
        
        <div class="menu-grid">
            <a href="${pageContext.request.contextPath}/user/profile.jsp" class="menu-item">
                <div class="icon">👤</div>
                <h3>个人中心</h3>
                <p>查看和修改个人信息</p>
            </a>
            
            <a href="${pageContext.request.contextPath}/appointment?action=list" class="menu-item">
                <div class="icon">📅</div>
                <h3>预约挂号</h3>
                <p>在线预约挂号服务</p>
            </a>
            
            <a href="${pageContext.request.contextPath}/user/records.jsp" class="menu-item">
                <div class="icon">📋</div>
                <h3>就诊记录</h3>
                <p>查看历史就诊记录</p>
            </a>
            
            <a href="${pageContext.request.contextPath}/user/valuecard.jsp" class="menu-item">
                <div class="icon">💳</div>
                <h3>储值卡管理</h3>
                <p>管理您的储值卡</p>
            </a>
            
            <a href="${pageContext.request.contextPath}/user/favorites.jsp" class="menu-item">
                <div class="icon">⭐</div>
                <h3>我的收藏</h3>
                <p>收藏的医生和服务</p>
            </a>
            
            <a href="${pageContext.request.contextPath}/user/messages.jsp" class="menu-item">
                <div class="icon">💬</div>
                <h3>消息中心</h3>
                <p>查看系统消息和通知</p>
            </a>
        </div>
    </div>
</body>
</html>
