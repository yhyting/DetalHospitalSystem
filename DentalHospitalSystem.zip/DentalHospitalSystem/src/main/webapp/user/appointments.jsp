<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.User" %>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.Appointment" %>
<%@ page import="java.util.List" %>
<%
    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
    List<Appointment> appointments = (List<Appointment>) request.getAttribute("appointments");
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>预约管理 - 口腔医院管理系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: #f5f5f5;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .toolbar {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 10px;
        }
        .table-container {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        .status {
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: 500;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-confirmed { background: #d1ecf1; color: #0c5460; }
        .status-completed { background: #d4edda; color: #155724; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
        .actions a {
            padding: 5px 10px;
            font-size: 12px;
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>预约管理</h1>
    </div>
    
    <div class="container">
        <div class="toolbar">
            <a href="${pageContext.request.contextPath}/appointment?action=add" class="btn">+ 新建预约</a>
            <a href="${pageContext.request.contextPath}/user/dashboard.jsp" class="btn" style="background: #6c757d;">返回首页</a>
        </div>
        
        <div class="table-container">
            <h2 style="margin-bottom: 20px;">我的预约</h2>
            <% if (appointments != null && !appointments.isEmpty()) { %>
                <table>
                    <thead>
                        <tr>
                            <th>预约日期</th>
                            <th>预约时间</th>
                            <th>科室</th>
                            <th>医生</th>
                            <th>症状描述</th>
                            <th>状态</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% for (Appointment appt : appointments) { %>
                            <tr>
                                <td><%= appt.getAppointmentDate() %></td>
                                <td><%= appt.getAppointmentTime() %></td>
                                <td><%= appt.getDepartment() %></td>
                                <td><%= appt.getDoctorName() != null ? appt.getDoctorName() : "待分配" %></td>
                                <td><%= appt.getSymptoms() %></td>
                                <td>
                                    <% 
                                        String statusClass = "status-pending";
                                        String statusText = "待确认";
                                        if ("confirmed".equals(appt.getStatus())) {
                                            statusClass = "status-confirmed";
                                            statusText = "已确认";
                                        } else if ("completed".equals(appt.getStatus())) {
                                            statusClass = "status-completed";
                                            statusText = "已完成";
                                        } else if ("cancelled".equals(appt.getStatus())) {
                                            statusClass = "status-cancelled";
                                            statusText = "已取消";
                                        }
                                    %>
                                    <span class="status <%= statusClass %>"><%= statusText %></span>
                                </td>
                                <td class="actions">
                                    <% if ("pending".equals(appt.getStatus())) { %>
                                        <a href="${pageContext.request.contextPath}/appointment?action=cancel&id=<%= appt.getId() %>" 
                                           class="btn" style="background: #dc3545;"
                                           onclick="return confirm('确定要取消此预约吗？')">取消</a>
                                    <% } %>
                                </td>
                            </tr>
                        <% } %>
                    </tbody>
                </table>
            <% } else { %>
                <p style="text-align: center; padding: 40px; color: #666;">
                    暂无预约记录<br>
                    <a href="${pageContext.request.contextPath}/appointment?action=add" class="btn" style="margin-top: 20px;">立即预约</a>
                </p>
            <% } %>
        </div>
    </div>
</body>
</html>
