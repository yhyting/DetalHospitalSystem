<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.User" %>
<%
    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>个人中心 - 口腔医院管理系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: #f5f5f5;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container {
            max-width: 1000px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .menu-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .menu-item {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            color: inherit;
        }
        .menu-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .menu-item.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .menu-item .icon {
            font-size: 32px;
            margin-bottom: 10px;
        }
        .menu-item h3 {
            font-size: 16px;
        }
        .card {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: none;
        }
        .card.active {
            display: block;
        }
        .info-row {
            display: flex;
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        .info-label {
            width: 120px;
            color: #666;
            font-weight: 500;
        }
        .info-value {
            flex: 1;
            color: #333;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        .form-group input {
            width: 100%;
            max-width: 400px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        .alert {
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>👤 个人中心</h1>
    </div>
    
    <div class="container">
        <div class="menu-grid">
            <div class="menu-item active" onclick="showTab('info')">
                <div class="icon">📋</div>
                <h3>查看信息</h3>
            </div>
            <div class="menu-item" onclick="showTab('edit')">
                <div class="icon">✏️</div>
                <h3>修改信息</h3>
            </div>
            <div class="menu-item" onclick="showTab('password')">
                <div class="icon">🔒</div>
                <h3>修改密码</h3>
            </div>
        </div>
        
        <!-- 查看信息 -->
        <div id="info" class="card active">
            <h2 style="margin-bottom: 20px;">我的信息</h2>
            <div class="info-row">
                <div class="info-label">用户名：</div>
                <div class="info-value"><%= user.getUsername() %></div>
            </div>
            <div class="info-row">
                <div class="info-label">真实姓名：</div>
                <div class="info-value"><%= user.getRealName() != null ? user.getRealName() : "未设置" %></div>
            </div>
            <div class="info-row">
                <div class="info-label">手机号码：</div>
                <div class="info-value"><%= user.getPhone() != null ? user.getPhone() : "未设置" %></div>
            </div>
            <div class="info-row">
                <div class="info-label">电子邮箱：</div>
                <div class="info-value"><%= user.getEmail() != null ? user.getEmail() : "未设置" %></div>
            </div>
            <div class="info-row">
                <div class="info-label">身份证号：</div>
                <div class="info-value"><%= user.getIdCard() != null ? user.getIdCard() : "未设置" %></div>
            </div>
            <div class="info-row">
                <div class="info-label">注册时间：</div>
                <div class="info-value"><%= user.getCreatedAt() %></div>
            </div>
        </div>
        
        <!-- 修改信息 -->
        <div id="edit" class="card">
            <h2 style="margin-bottom: 20px;">修改个人信息</h2>
            <% if (request.getParameter("editSuccess") != null) { %>
                <div class="alert alert-success">信息修改成功！</div>
            <% } %>
            <form action="${pageContext.request.contextPath}/user/updateProfile" method="post">
                <div class="form-group">
                    <label>用户名：</label>
                    <input type="text" value="<%= user.getUsername() %>" disabled>
                </div>
                <div class="form-group">
                    <label>真实姓名：</label>
                    <input type="text" name="realName" value="<%= user.getRealName() != null ? user.getRealName() : "" %>">
                </div>
                <div class="form-group">
                    <label>手机号码：</label>
                    <input type="tel" name="phone" value="<%= user.getPhone() != null ? user.getPhone() : "" %>">
                </div>
                <div class="form-group">
                    <label>电子邮箱：</label>
                    <input type="email" name="email" value="<%= user.getEmail() != null ? user.getEmail() : "" %>">
                </div>
                <div class="form-group">
                    <label>身份证号：</label>
                    <input type="text" name="idCard" value="<%= user.getIdCard() != null ? user.getIdCard() : "" %>">
                </div>
                <button type="submit" class="btn btn-primary">保存修改</button>
            </form>
        </div>
        
        <!-- 修改密码 -->
        <div id="password" class="card">
            <h2 style="margin-bottom: 20px;">修改密码</h2>
            <% if (request.getParameter("pwdSuccess") != null) { %>
                <div class="alert alert-success">密码修改成功！</div>
            <% } %>
            <% if (request.getParameter("pwdError") != null) { %>
                <div class="alert alert-error"><%= request.getParameter("pwdError") %></div>
            <% } %>
            <form action="${pageContext.request.contextPath}/user/changePassword" method="post">
                <div class="form-group">
                    <label>当前密码：</label>
                    <input type="password" name="oldPassword" required>
                </div>
                <div class="form-group">
                    <label>新密码：</label>
                    <input type="password" name="newPassword" required minlength="6">
                </div>
                <div class="form-group">
                    <label>确认新密码：</label>
                    <input type="password" name="confirmPassword" required minlength="6">
                </div>
                <button type="submit" class="btn btn-primary">修改密码</button>
            </form>
        </div>
        
        <div style="margin-top: 20px;">
            <a href="${pageContext.request.contextPath}/user/dashboard.jsp" class="btn btn-secondary">返回首页</a>
        </div>
    </div>
    
    <script>
        function showTab(tabName) {
            // 隐藏所有卡片
            document.querySelectorAll('.card').forEach(card => {
                card.classList.remove('active');
            });
            // 移除所有菜单项的active
            document.querySelectorAll('.menu-item').forEach(item => {
                item.classList.remove('active');
            });
            
            // 显示选中的卡片
            document.getElementById(tabName).classList.add('active');
            // 添加菜单项active
            event.currentTarget.classList.add('active');
        }
    </script>
</body>
</html>
