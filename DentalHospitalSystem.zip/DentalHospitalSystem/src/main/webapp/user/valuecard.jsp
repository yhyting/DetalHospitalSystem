<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.User" %>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.ValueCard" %>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.CardTransaction" %>
<%@ page import="com.yhyting.dentalhospitalsystem.dao.ValueCardDAO" %>
<%@ page import="java.util.List" %>
<%
    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
    
    ValueCardDAO cardDAO = new ValueCardDAO();
    ValueCard card = cardDAO.findByUserId(user.getId());
    List<CardTransaction> transactions = null;
    
    if (card != null) {
        transactions = cardDAO.getTransactions(card.getId());
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>储值卡管理 - 口腔医院管理系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: #f5f5f5;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .card-info {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 15px;
            padding: 30px;
            color: white;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .card-number {
            font-size: 24px;
            letter-spacing: 4px;
            margin-bottom: 20px;
        }
        .balance {
            font-size: 48px;
            font-weight: bold;
            margin: 20px 0;
        }
        .balance-label {
            font-size: 14px;
            opacity: 0.9;
        }
        .card-stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-top: 20px;
        }
        .stat-item {
            background: rgba(255,255,255,0.2);
            padding: 15px;
            border-radius: 10px;
        }
        .stat-label {
            font-size: 12px;
            opacity: 0.9;
        }
        .stat-value {
            font-size: 24px;
            font-weight: bold;
            margin-top: 5px;
        }
        .actions {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        .transactions {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .tab-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            border-bottom: 2px solid #eee;
        }
        .tab-btn {
            padding: 10px 20px;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 14px;
            color: #666;
            border-bottom: 2px solid transparent;
            margin-bottom: -2px;
        }
        .tab-btn.active {
            color: #667eea;
            border-bottom-color: #667eea;
            font-weight: bold;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        .type-recharge {
            color: #28a745;
            font-weight: bold;
        }
        .type-consume {
            color: #dc3545;
            font-weight: bold;
        }
        .no-card {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 10px;
        }
        .no-card .icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
        }
        .modal-content {
            background: white;
            width: 500px;
            margin: 100px auto;
            border-radius: 10px;
            padding: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>💳 储值卡管理</h1>
    </div>
    
    <div class="container">
        <% if (card != null) { %>
            <!-- 储值卡信息 -->
            <div class="card-info">
                <div class="card-number">卡号: <%= card.getCardNumber() %></div>
                <div class="balance-label">当前余额</div>
                <div class="balance">¥ <%= String.format("%.2f", card.getBalance()) %></div>
                
                <div class="card-stats">
                    <div class="stat-item">
                        <div class="stat-label">累计充值</div>
                        <div class="stat-value">¥ <%= String.format("%.2f", card.getTotalRecharge()) %></div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">卡片状态</div>
                        <div class="stat-value"><%= card.getStatus() == 1 ? "正常" : "冻结" %></div>
                    </div>
                </div>
            </div>
            
            <!-- 操作按钮 -->
            <div class="actions">
                <button onclick="showRechargeModal()" class="btn btn-primary">💰 充值</button>
                <a href="${pageContext.request.contextPath}/user/dashboard.jsp" class="btn btn-secondary">返回首页</a>
            </div>
            
            <!-- 交易记录 -->
            <div class="transactions">
                <div class="tab-buttons">
                    <button class="tab-btn active" onclick="filterTransactions('all')">全部记录</button>
                    <button class="tab-btn" onclick="filterTransactions('recharge')">充值记录</button>
                    <button class="tab-btn" onclick="filterTransactions('consume')">消费记录</button>
                </div>
                
                <% if (transactions != null && !transactions.isEmpty()) { %>
                    <table id="transactionTable">
                        <thead>
                            <tr>
                                <th>时间</th>
                                <th>类型</th>
                                <th>金额</th>
                                <th>交易前余额</th>
                                <th>交易后余额</th>
                                <th>说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% for (CardTransaction t : transactions) { %>
                                <tr class="<%= t.getTransactionType() %>">
                                    <td><%= t.getCreatedAt() %></td>
                                    <td class="type-<%= t.getTransactionType() %>">
                                        <%= "recharge".equals(t.getTransactionType()) ? "充值" : "消费" %>
                                    </td>
                                    <td class="type-<%= t.getTransactionType() %>">
                                        <%= "recharge".equals(t.getTransactionType()) ? "+" : "-" %>
                                        ¥ <%= String.format("%.2f", t.getAmount()) %>
                                    </td>
                                    <td>¥ <%= String.format("%.2f", t.getBalanceBefore()) %></td>
                                    <td>¥ <%= String.format("%.2f", t.getBalanceAfter()) %></td>
                                    <td><%= t.getDescription() != null ? t.getDescription() : "-" %></td>
                                </tr>
                            <% } %>
                        </tbody>
                    </table>
                <% } else { %>
                    <p style="text-align: center; padding: 40px; color: #666;">暂无交易记录</p>
                <% } %>
            </div>
        <% } else { %>
            <!-- 未开通储值卡 -->
            <div class="no-card">
                <div class="icon">💳</div>
                <h2 style="margin-bottom: 10px;">您还未开通储值卡</h2>
                <p style="color: #666; margin-bottom: 30px;">开通储值卡后，可享受更便捷的支付体验</p>
                <a href="${pageContext.request.contextPath}/user/createCard" class="btn btn-primary">立即开通</a>
            </div>
        <% } %>
    </div>
    
    <!-- 充值模态框 -->
    <div id="rechargeModal" class="modal">
        <div class="modal-content">
            <h2 style="margin-bottom: 20px;">储值卡充值</h2>
            <form action="${pageContext.request.contextPath}/user/rechargeCard" method="post">
                <div class="form-group">
                    <label>充值金额：</label>
                    <input type="number" name="amount" step="0.01" min="1" required placeholder="请输入充值金额">
                </div>
                <div class="form-group">
                    <label>备注说明：</label>
                    <input type="text" name="description" placeholder="选填">
                </div>
                <button type="submit" class="btn btn-primary">确认充值</button>
                <button type="button" onclick="closeRechargeModal()" class="btn btn-secondary">取消</button>
            </form>
        </div>
    </div>
    
    <script>
        function showRechargeModal() {
            document.getElementById('rechargeModal').style.display = 'block';
        }
        
        function closeRechargeModal() {
            document.getElementById('rechargeModal').style.display = 'none';
        }
        
        function filterTransactions(type) {
            const rows = document.querySelectorAll('#transactionTable tbody tr');
            const buttons = document.querySelectorAll('.tab-btn');
            
            buttons.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            rows.forEach(row => {
                if (type === 'all') {
                    row.style.display = '';
                } else {
                    row.style.display = row.classList.contains(type) ? '' : 'none';
                }
            });
        }
        
        // 点击模态框外部关闭
        window.onclick = function(event) {
            const modal = document.getElementById('rechargeModal');
            if (event.target == modal) {
                closeRechargeModal();
            }
        }
    </script>
</body>
</html>
