<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.User" %>
<%@ page import="com.yhyting.dentalhospitalsystem.entity.MedicalRecord" %>
<%@ page import="com.yhyting.dentalhospitalsystem.dao.MedicalRecordDAO" %>
<%@ page import="java.util.List" %>
<%
    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
    
    MedicalRecordDAO recordDAO = new MedicalRecordDAO();
    List<MedicalRecord> records = recordDAO.findByUserId(user.getId());
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>就诊记录 - 口腔医院管理系统</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: #f5f5f5;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .toolbar {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 10px;
        }
        .btn-secondary {
            background: #6c757d;
        }
        .records-grid {
            display: grid;
            gap: 20px;
        }
        .record-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .record-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .record-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }
        .record-date {
            font-size: 18px;
            font-weight: bold;
            color: #667eea;
        }
        .record-cost {
            font-size: 20px;
            font-weight: bold;
            color: #28a745;
        }
        .record-info {
            display: grid;
            grid-template-columns: 120px 1fr;
            gap: 15px;
            margin-bottom: 15px;
        }
        .info-label {
            color: #666;
            font-weight: 500;
        }
        .info-value {
            color: #333;
        }
        .diagnosis-box {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-top: 15px;
        }
        .diagnosis-title {
            font-weight: bold;
            color: #667eea;
            margin-bottom: 10px;
        }
        .no-records {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 10px;
        }
        .no-records .icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>📋 就诊记录</h1>
    </div>
    
    <div class="container">
        <div class="toolbar">
            <a href="${pageContext.request.contextPath}/user/dashboard.jsp" class="btn btn-secondary">返回首页</a>
        </div>
        
        <% if (records != null && !records.isEmpty()) { %>
            <div class="records-grid">
                <% for (MedicalRecord record : records) { %>
                    <div class="record-card">
                        <div class="record-header">
                            <div class="record-date">
                                <%= new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(record.getVisitDate()) %>
                            </div>
                            <div class="record-cost">
                                ¥ <%= String.format("%.2f", record.getCost()) %>
                            </div>
                        </div>
                        
                        <div class="record-info">
                            <div class="info-label">主治医生：</div>
                            <div class="info-value"><%= record.getDoctorName() != null ? record.getDoctorName() : "未分配" %></div>
                        </div>
                        
                        <div class="diagnosis-box">
                            <div class="diagnosis-title">诊断结果</div>
                            <div><%= record.getDiagnosis() != null ? record.getDiagnosis() : "无" %></div>
                        </div>
                        
                        <% if (record.getTreatment() != null && !record.getTreatment().isEmpty()) { %>
                            <div class="diagnosis-box" style="margin-top: 10px;">
                                <div class="diagnosis-title">治疗方案</div>
                                <div><%= record.getTreatment() %></div>
                            </div>
                        <% } %>
                        
                        <% if (record.getPrescription() != null && !record.getPrescription().isEmpty()) { %>
                            <div class="diagnosis-box" style="margin-top: 10px;">
                                <div class="diagnosis-title">处方药品</div>
                                <div><%= record.getPrescription() %></div>
                            </div>
                        <% } %>
                    </div>
                <% } %>
            </div>
        <% } else { %>
            <div class="no-records">
                <div class="icon">📋</div>
                <h2 style="margin-bottom: 10px;">暂无就诊记录</h2>
                <p style="color: #666; margin-bottom: 30px;">您还没有任何就诊记录</p>
                <a href="${pageContext.request.contextPath}/appointment?action=add" class="btn">立即预约</a>
            </div>
        <% } %>
    </div>
</body>
</html>
