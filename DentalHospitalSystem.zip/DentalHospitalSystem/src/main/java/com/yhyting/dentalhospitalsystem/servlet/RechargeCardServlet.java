package com.yhyting.dentalhospitalsystem.servlet;

import com.yhyting.dentalhospitalsystem.dao.ValueCardDAO;
import com.yhyting.dentalhospitalsystem.dao.MessageDAO;
import com.yhyting.dentalhospitalsystem.entity.User;
import com.yhyting.dentalhospitalsystem.entity.ValueCard;
import com.yhyting.dentalhospitalsystem.entity.Message;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;

@WebServlet("/user/rechargeCard")
public class RechargeCardServlet extends HttpServlet {
    private ValueCardDAO cardDAO = new ValueCardDAO();
    private MessageDAO messageDAO = new MessageDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        try {
            String amountStr = request.getParameter("amount");
            String description = request.getParameter("description");

            BigDecimal amount = new BigDecimal(amountStr);

            if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                response.sendRedirect(request.getContextPath() + "/user/valuecard.jsp?error=充值金额必须大于0");
                return;
            }

            // 获取用户的储值卡
            ValueCard card = cardDAO.findByUserId(user.getId());
            if (card == null) {
                response.sendRedirect(request.getContextPath() + "/user/valuecard.jsp?error=储值卡不存在");
                return;
            }

            // 充值
            if (description == null || description.trim().isEmpty()) {
                description = "储值卡充值";
            }

            if (cardDAO.recharge(card.getId(), amount, description)) {
                // 发送充值成功消息
                sendRechargeMessage(user.getId(), amount);

                response.sendRedirect(request.getContextPath() + "/user/valuecard.jsp?success=true");
            } else {
                response.sendRedirect(request.getContextPath() + "/user/valuecard.jsp?error=true");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/user/valuecard.jsp?error=充值失败:" + e.getMessage());
        }
    }

    /**
     * 发送充值成功消息
     */
    private void sendRechargeMessage(Integer userId, BigDecimal amount) {
        Message message = new Message();
        message.setUserId(userId);
        message.setTitle("充值成功");
        message.setContent("您已成功充值 ¥" + amount + " 元,请在储值卡页面查看最新余额。");
        message.setType("system");
        message.setIsRead(0);
        messageDAO.add(message);
    }
}
