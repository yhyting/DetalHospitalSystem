package com.yhyting.dentalhospitalsystem.dao;

import com.yhyting.dentalhospitalsystem.entity.MedicalRecord;
import com.yhyting.dentalhospitalsystem.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicalRecordDAO {

    /**
     * 根据用户ID查询就诊记录
     */
    public List<MedicalRecord> findByUserId(Integer userId) {
        List<MedicalRecord> records = new ArrayList<>();
        String sql = "SELECT mr.*, u1.real_name as user_name, u2.real_name as doctor_name " +
                     "FROM medical_records mr " +
                     "LEFT JOIN users u1 ON mr.user_id = u1.id " +
                     "LEFT JOIN users u2 ON mr.doctor_id = u2.id " +
                     "WHERE mr.user_id = ? ORDER BY mr.visit_date DESC";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                records.add(extractMedicalRecord(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        
        return records;
    }

    /**
     * 根据医生ID查询就诊记录
     */
    public List<MedicalRecord> findByDoctorId(Integer doctorId) {
        List<MedicalRecord> records = new ArrayList<>();
        String sql = "SELECT mr.*, u1.real_name as user_name, u2.real_name as doctor_name " +
                     "FROM medical_records mr " +
                     "LEFT JOIN users u1 ON mr.user_id = u1.id " +
                     "LEFT JOIN users u2 ON mr.doctor_id = u2.id " +
                     "WHERE mr.doctor_id = ? ORDER BY mr.visit_date DESC";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, doctorId);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                records.add(extractMedicalRecord(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        
        return records;
    }

    /**
     * 查询所有就诊记录
     */
    public List<MedicalRecord> findAll() {
        List<MedicalRecord> records = new ArrayList<>();
        String sql = "SELECT mr.*, u1.real_name as user_name, u2.real_name as doctor_name " +
                     "FROM medical_records mr " +
                     "LEFT JOIN users u1 ON mr.user_id = u1.id " +
                     "LEFT JOIN users u2 ON mr.doctor_id = u2.id " +
                     "ORDER BY mr.visit_date DESC";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                records.add(extractMedicalRecord(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        
        return records;
    }

    /**
     * 添加就诊记录
     */
    public boolean add(MedicalRecord record) {
        String sql = "INSERT INTO medical_records (user_id, doctor_id, appointment_id, diagnosis, treatment, prescription, cost, visit_date) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try {
            return DBUtil.executeUpdate(sql,
                record.getUserId(),
                record.getDoctorId(),
                record.getAppointmentId(),
                record.getDiagnosis(),
                record.getTreatment(),
                record.getPrescription(),
                record.getCost(),
                record.getVisitDate()
            ) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 根据ID查询就诊记录
     */
    public MedicalRecord findById(Integer id) {
        String sql = "SELECT mr.*, u1.real_name as user_name, u2.real_name as doctor_name " +
                     "FROM medical_records mr " +
                     "LEFT JOIN users u1 ON mr.user_id = u1.id " +
                     "LEFT JOIN users u2 ON mr.doctor_id = u2.id " +
                     "WHERE mr.id = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractMedicalRecord(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        
        return null;
    }

    /**
     * 从ResultSet提取MedicalRecord对象
     */
    private MedicalRecord extractMedicalRecord(ResultSet rs) throws SQLException {
        MedicalRecord record = new MedicalRecord();
        record.setId(rs.getInt("id"));
        record.setUserId(rs.getInt("user_id"));
        record.setDoctorId(rs.getInt("doctor_id"));
        
        int appointmentId = rs.getInt("appointment_id");
        if (!rs.wasNull()) {
            record.setAppointmentId(appointmentId);
        }
        
        record.setDiagnosis(rs.getString("diagnosis"));
        record.setTreatment(rs.getString("treatment"));
        record.setPrescription(rs.getString("prescription"));
        record.setCost(rs.getBigDecimal("cost"));
        record.setVisitDate(rs.getTimestamp("visit_date"));
        record.setCreatedAt(rs.getTimestamp("created_at"));
        record.setUserName(rs.getString("user_name"));
        record.setDoctorName(rs.getString("doctor_name"));
        
        return record;
    }
}
