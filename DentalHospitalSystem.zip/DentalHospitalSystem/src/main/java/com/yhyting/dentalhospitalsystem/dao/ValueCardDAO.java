package com.yhyting.dentalhospitalsystem.dao;

import com.yhyting.dentalhospitalsystem.entity.ValueCard;
import com.yhyting.dentalhospitalsystem.entity.CardTransaction;
import com.yhyting.dentalhospitalsystem.util.DBUtil;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ValueCardDAO {

    /**
     * 根据用户ID查询储值卡
     */
    public ValueCard findByUserId(Integer userId) {
        String sql = "SELECT vc.*, u.real_name as user_name FROM value_cards vc " +
                     "LEFT JOIN users u ON vc.user_id = u.id " +
                     "WHERE vc.user_id = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractValueCard(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        
        return null;
    }

    /**
     * 创建储值卡
     */
    public boolean create(ValueCard card) {
        String sql = "INSERT INTO value_cards (user_id, card_number, balance, total_recharge, status) " +
                     "VALUES (?, ?, ?, ?, ?)";
        
        try {
            return DBUtil.executeUpdate(sql, 
                card.getUserId(), 
                card.getCardNumber(), 
                card.getBalance(), 
                card.getTotalRecharge(),
                card.getStatus()
            ) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 充值
     */
    public boolean recharge(Integer cardId, BigDecimal amount, String description) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            conn.setAutoCommit(false); // 开启事务
            
            // 1. 查询当前余额
            String selectSql = "SELECT balance, total_recharge FROM value_cards WHERE id = ? FOR UPDATE";
            pstmt = conn.prepareStatement(selectSql);
            pstmt.setInt(1, cardId);
            rs = pstmt.executeQuery();
            
            if (!rs.next()) {
                conn.rollback();
                return false;
            }
            
            BigDecimal currentBalance = rs.getBigDecimal("balance");
            BigDecimal totalRecharge = rs.getBigDecimal("total_recharge");
            BigDecimal newBalance = currentBalance.add(amount);
            BigDecimal newTotalRecharge = totalRecharge.add(amount);
            
            rs.close();
            pstmt.close();
            
            // 2. 更新余额
            String updateSql = "UPDATE value_cards SET balance = ?, total_recharge = ? WHERE id = ?";
            pstmt = conn.prepareStatement(updateSql);
            pstmt.setBigDecimal(1, newBalance);
            pstmt.setBigDecimal(2, newTotalRecharge);
            pstmt.setInt(3, cardId);
            pstmt.executeUpdate();
            pstmt.close();
            
            // 3. 记录交易
            String insertSql = "INSERT INTO card_transactions (card_id, transaction_type, amount, balance_before, balance_after, description) " +
                              "VALUES (?, 'recharge', ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(insertSql);
            pstmt.setInt(1, cardId);
            pstmt.setBigDecimal(2, amount);
            pstmt.setBigDecimal(3, currentBalance);
            pstmt.setBigDecimal(4, newBalance);
            pstmt.setString(5, description);
            pstmt.executeUpdate();
            
            conn.commit(); // 提交事务
            return true;
            
        } catch (SQLException e) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (conn != null) conn.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            DBUtil.close(conn, pstmt, rs);
        }
    }

    /**
     * 消费扣款
     */
    public boolean consume(Integer cardId, BigDecimal amount, String description) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            conn.setAutoCommit(false);
            
            // 1. 查询当前余额
            String selectSql = "SELECT balance FROM value_cards WHERE id = ? FOR UPDATE";
            pstmt = conn.prepareStatement(selectSql);
            pstmt.setInt(1, cardId);
            rs = pstmt.executeQuery();
            
            if (!rs.next()) {
                conn.rollback();
                return false;
            }
            
            BigDecimal currentBalance = rs.getBigDecimal("balance");
            
            // 检查余额是否足够
            if (currentBalance.compareTo(amount) < 0) {
                conn.rollback();
                return false;
            }
            
            BigDecimal newBalance = currentBalance.subtract(amount);
            
            rs.close();
            pstmt.close();
            
            // 2. 更新余额
            String updateSql = "UPDATE value_cards SET balance = ? WHERE id = ?";
            pstmt = conn.prepareStatement(updateSql);
            pstmt.setBigDecimal(1, newBalance);
            pstmt.setInt(2, cardId);
            pstmt.executeUpdate();
            pstmt.close();
            
            // 3. 记录交易
            String insertSql = "INSERT INTO card_transactions (card_id, transaction_type, amount, balance_before, balance_after, description) " +
                              "VALUES (?, 'consume', ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(insertSql);
            pstmt.setInt(1, cardId);
            pstmt.setBigDecimal(2, amount);
            pstmt.setBigDecimal(3, currentBalance);
            pstmt.setBigDecimal(4, newBalance);
            pstmt.setString(5, description);
            pstmt.executeUpdate();
            
            conn.commit();
            return true;
            
        } catch (SQLException e) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (conn != null) conn.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            DBUtil.close(conn, pstmt, rs);
        }
    }

    /**
     * 查询交易记录
     */
    public List<CardTransaction> getTransactions(Integer cardId) {
        List<CardTransaction> transactions = new ArrayList<>();
        String sql = "SELECT * FROM card_transactions WHERE card_id = ? ORDER BY created_at DESC";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, cardId);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                transactions.add(extractTransaction(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        
        return transactions;
    }

    /**
     * 从ResultSet提取ValueCard对象
     */
    private ValueCard extractValueCard(ResultSet rs) throws SQLException {
        ValueCard card = new ValueCard();
        card.setId(rs.getInt("id"));
        card.setUserId(rs.getInt("user_id"));
        card.setCardNumber(rs.getString("card_number"));
        card.setBalance(rs.getBigDecimal("balance"));
        card.setTotalRecharge(rs.getBigDecimal("total_recharge"));
        card.setStatus(rs.getInt("status"));
        card.setCreatedAt(rs.getTimestamp("created_at"));
        card.setUpdatedAt(rs.getTimestamp("updated_at"));
        
        String userName = rs.getString("user_name");
        if (userName != null) {
            card.setUserName(userName);
        }
        
        return card;
    }

    /**
     * 从ResultSet提取CardTransaction对象
     */
    private CardTransaction extractTransaction(ResultSet rs) throws SQLException {
        CardTransaction transaction = new CardTransaction();
        transaction.setId(rs.getInt("id"));
        transaction.setCardId(rs.getInt("card_id"));
        transaction.setTransactionType(rs.getString("transaction_type"));
        transaction.setAmount(rs.getBigDecimal("amount"));
        transaction.setBalanceBefore(rs.getBigDecimal("balance_before"));
        transaction.setBalanceAfter(rs.getBigDecimal("balance_after"));
        transaction.setDescription(rs.getString("description"));
        transaction.setCreatedAt(rs.getTimestamp("created_at"));
        return transaction;
    }
}
