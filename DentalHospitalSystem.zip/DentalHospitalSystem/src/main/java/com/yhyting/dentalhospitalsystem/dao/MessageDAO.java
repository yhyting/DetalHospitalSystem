package com.yhyting.dentalhospitalsystem.dao;

import com.yhyting.dentalhospitalsystem.entity.Message;
import com.yhyting.dentalhospitalsystem.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MessageDAO {

    /**
     * 添加消息
     */
    public boolean add(Message message) {
        String sql = "INSERT INTO messages (user_id, title, content, type, is_read) VALUES (?, ?, ?, ?, ?)";
        try {
            return DBUtil.executeUpdate(sql,
                message.getUserId(),
                message.getTitle(),
                message.getContent(),
                message.getType(),
                message.getIsRead() != null ? message.getIsRead() : 0
            ) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 根据用户ID查询消息
     */
    public List<Message> findByUserId(Integer userId) {
        List<Message> messages = new ArrayList<>();
        String sql = "SELECT * FROM messages WHERE user_id = ? ORDER BY created_at DESC";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                messages.add(extractMessage(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        
        return messages;
    }

    /**
     * 标记为已读
     */
    public boolean markAsRead(Integer messageId) {
        String sql = "UPDATE messages SET is_read = 1 WHERE id = ?";
        try {
            return DBUtil.executeUpdate(sql, messageId) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 标记所有消息为已读
     */
    public boolean markAllAsRead(Integer userId) {
        String sql = "UPDATE messages SET is_read = 1 WHERE user_id = ? AND is_read = 0";
        try {
            return DBUtil.executeUpdate(sql, userId) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 删除消息
     */
    public boolean delete(Integer messageId) {
        String sql = "DELETE FROM messages WHERE id = ?";
        try {
            return DBUtil.executeUpdate(sql, messageId) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 获取未读消息数量
     */
    public int getUnreadCount(Integer userId) {
        String sql = "SELECT COUNT(*) FROM messages WHERE user_id = ? AND is_read = 0";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        
        return 0;
    }

    /**
     * 从ResultSet提取Message对象
     */
    private Message extractMessage(ResultSet rs) throws SQLException {
        Message message = new Message();
        message.setId(rs.getInt("id"));
        message.setUserId(rs.getInt("user_id"));
        message.setTitle(rs.getString("title"));
        message.setContent(rs.getString("content"));
        message.setType(rs.getString("type"));
        message.setIsRead(rs.getInt("is_read"));
        message.setCreatedAt(rs.getTimestamp("created_at"));
        return message;
    }
}
