package com.yhyting.dentalhospitalsystem.servlet;

import com.yhyting.dentalhospitalsystem.dao.FavoriteDAO;
import com.yhyting.dentalhospitalsystem.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/favorite")
public class FavoriteServlet extends HttpServlet {
    private FavoriteDAO favoriteDAO = new FavoriteDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        PrintWriter out = response.getWriter();

        if (user == null) {
            out.print("{\"success\":false,\"message\":\"未登录\"}");
            out.flush();
            return;
        }

        String action = request.getParameter("action");
        String doctorIdStr = request.getParameter("doctorId");

        boolean success = false;
        String message = "";

        try {
            if (doctorIdStr == null || doctorIdStr.isEmpty()) {
                message = "参数错误";
            } else {
                Integer doctorId = Integer.parseInt(doctorIdStr);

                if ("add".equals(action)) {
                    // 添加收藏
                    success = favoriteDAO.add(user.getId(), doctorId);
                    message = success ? "收藏成功" : "已收藏或添加失败";

                } else if ("remove".equals(action)) {
                    // 取消收藏
                    success = favoriteDAO.remove(user.getId(), doctorId);
                    message = success ? "已取消收藏" : "取消失败";

                } else {
                    message = "未知操作";
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            success = false;
            message = "操作失败:" + e.getMessage();
        }

        // 返回JSON响应
        out.print("{\"success\":" + success + ",\"message\":\"" + message + "\"}");
        out.flush();
    }
}