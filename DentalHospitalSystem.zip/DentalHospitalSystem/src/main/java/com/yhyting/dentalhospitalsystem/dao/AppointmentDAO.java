package com.yhyting.dentalhospitalsystem.dao;

import com.yhyting.dentalhospitalsystem.entity.Appointment;
import com.yhyting.dentalhospitalsystem.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO {

    /**
     * 添加预约
     */
    public boolean add(Appointment appointment) {
        String sql = "INSERT INTO appointments (user_id, doctor_id, appointment_date, appointment_time, department, symptoms, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try {
            Connection conn = DBUtil.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, appointment.getUserId());
            pstmt.setObject(2, appointment.getDoctorId());
            pstmt.setDate(3, appointment.getAppointmentDate());
            pstmt.setString(4, appointment.getAppointmentTime());
            pstmt.setString(5, appointment.getDepartment());
            pstmt.setString(6, appointment.getSymptoms());
            pstmt.setString(7, appointment.getStatus() != null ? appointment.getStatus() : "pending");
            
            int result = pstmt.executeUpdate();
            DBUtil.close(conn, pstmt);
            
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 根据用户ID查询预约
     */
    public List<Appointment> findByUserId(Integer userId) {
        List<Appointment> appointments = new ArrayList<>();
        String sql = "SELECT a.*, u1.real_name as user_name, u2.real_name as doctor_name " +
                     "FROM appointments a " +
                     "LEFT JOIN users u1 ON a.user_id = u1.id " +
                     "LEFT JOIN users u2 ON a.doctor_id = u2.id " +
                     "WHERE a.user_id = ? ORDER BY a.appointment_date DESC, a.appointment_time DESC";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                appointments.add(extractAppointment(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        
        return appointments;
    }

    /**
     * 根据医生ID查询预约
     */
    public List<Appointment> findByDoctorId(Integer doctorId) {
        List<Appointment> appointments = new ArrayList<>();
        String sql = "SELECT a.*, u1.real_name as user_name, u2.real_name as doctor_name " +
                     "FROM appointments a " +
                     "LEFT JOIN users u1 ON a.user_id = u1.id " +
                     "LEFT JOIN users u2 ON a.doctor_id = u2.id " +
                     "WHERE a.doctor_id = ? ORDER BY a.appointment_date DESC, a.appointment_time DESC";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, doctorId);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                appointments.add(extractAppointment(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        
        return appointments;
    }

    /**
     * 查询所有预约
     */
    public List<Appointment> findAll() {
        List<Appointment> appointments = new ArrayList<>();
        String sql = "SELECT a.*, u1.real_name as user_name, u2.real_name as doctor_name " +
                     "FROM appointments a " +
                     "LEFT JOIN users u1 ON a.user_id = u1.id " +
                     "LEFT JOIN users u2 ON a.doctor_id = u2.id " +
                     "ORDER BY a.appointment_date DESC, a.appointment_time DESC";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                appointments.add(extractAppointment(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        
        return appointments;
    }

    /**
     * 根据ID查询预约
     */
    public Appointment findById(Integer id) {
        String sql = "SELECT a.*, u1.real_name as user_name, u2.real_name as doctor_name " +
                     "FROM appointments a " +
                     "LEFT JOIN users u1 ON a.user_id = u1.id " +
                     "LEFT JOIN users u2 ON a.doctor_id = u2.id " +
                     "WHERE a.id = ?";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractAppointment(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        
        return null;
    }

    /**
     * 更新预约状态
     */
    public boolean updateStatus(Integer id, String status) {
        String sql = "UPDATE appointments SET status = ? WHERE id = ?";
        
        try {
            return DBUtil.executeUpdate(sql, status, id) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 删除预约
     */
    public boolean delete(Integer id) {
        String sql = "DELETE FROM appointments WHERE id = ?";
        
        try {
            return DBUtil.executeUpdate(sql, id) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 从ResultSet提取Appointment对象
     */
    private Appointment extractAppointment(ResultSet rs) throws SQLException {
        Appointment appointment = new Appointment();
        appointment.setId(rs.getInt("id"));
        appointment.setUserId(rs.getInt("user_id"));
        
        int doctorId = rs.getInt("doctor_id");
        if (!rs.wasNull()) {
            appointment.setDoctorId(doctorId);
        }
        
        appointment.setAppointmentDate(rs.getDate("appointment_date"));
        appointment.setAppointmentTime(rs.getString("appointment_time"));
        appointment.setDepartment(rs.getString("department"));
        appointment.setSymptoms(rs.getString("symptoms"));
        appointment.setStatus(rs.getString("status"));
        appointment.setCreatedAt(rs.getTimestamp("created_at"));
        appointment.setUpdatedAt(rs.getTimestamp("updated_at"));
        appointment.setUserName(rs.getString("user_name"));
        appointment.setDoctorName(rs.getString("doctor_name"));
        
        return appointment;
    }
}
