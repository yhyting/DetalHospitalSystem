package com.yhyting.dentalhospitalsystem.servlet;

import com.yhyting.dentalhospitalsystem.dao.AppointmentDAO;
import com.yhyting.dentalhospitalsystem.dao.MessageDAO;
import com.yhyting.dentalhospitalsystem.entity.Appointment;
import com.yhyting.dentalhospitalsystem.entity.Message;
import com.yhyting.dentalhospitalsystem.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Date;
import java.util.List;

@WebServlet("/appointment")
public class AppointmentServlet extends HttpServlet {
    private AppointmentDAO appointmentDAO = new AppointmentDAO();
    private MessageDAO messageDAO = new MessageDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "list":
                listAppointments(request, response);
                break;
            case "add":
                showAddForm(request, response);
                break;
            case "delete":
                deleteAppointment(request, response);
                break;
            case "cancel":
                cancelAppointment(request, response);
                break;
            default:
                listAppointments(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            addAppointment(request, response);
        } else if ("update".equals(action)) {
            updateAppointmentStatus(request, response);
        }
    }

    private void listAppointments(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        List<Appointment> appointments;

        if ("admin".equals(user.getRole())) {
            appointments = appointmentDAO.findAll();
        } else if ("doctor".equals(user.getRole())) {
            appointments = appointmentDAO.findByDoctorId(user.getId());
        } else {
            appointments = appointmentDAO.findByUserId(user.getId());
        }

        request.setAttribute("appointments", appointments);
        request.getRequestDispatcher("/user/appointments.jsp").forward(request, response);
    }

    private void showAddForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/user/add-appointment.jsp").forward(request, response);
    }

    private void addAppointment(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String dateStr = request.getParameter("appointmentDate");
        String time = request.getParameter("appointmentTime");
        String department = request.getParameter("department");
        String symptoms = request.getParameter("symptoms");
        String doctorIdStr = request.getParameter("doctorId");

        Appointment appointment = new Appointment();
        appointment.setUserId(user.getId());

        if (doctorIdStr != null && !doctorIdStr.isEmpty()) {
            appointment.setDoctorId(Integer.parseInt(doctorIdStr));
        }

        appointment.setAppointmentDate(Date.valueOf(dateStr));
        appointment.setAppointmentTime(time);
        appointment.setDepartment(department);
        appointment.setSymptoms(symptoms);
        appointment.setStatus("pending");

        if (appointmentDAO.add(appointment)) {
            // 发送预约成功消息
            sendAppointmentMessage(user.getId(),
                    "预约成功",
                    "您已成功预约 " + department + " 于 " + dateStr + " " + time + "。请准时就诊。",
                    "appointment");

            response.sendRedirect(request.getContextPath() + "/appointment?action=list");
        } else {
            request.setAttribute("error", "预约失败,请稍后再试!");
            request.getRequestDispatcher("/user/add-appointment.jsp").forward(request, response);
        }
    }

    private void updateAppointmentStatus(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idStr = request.getParameter("id");
        String status = request.getParameter("status");

        if (idStr != null && status != null) {
            Integer id = Integer.parseInt(idStr);
            Appointment appointment = appointmentDAO.findById(id);

            if (appointment != null && appointmentDAO.updateStatus(id, status)) {
                // 根据状态发送不同的消息
                String title = "";
                String content = "";

                if ("confirmed".equals(status)) {
                    title = "预约已确认";
                    content = "您的预约已被确认,请准时就诊。";
                } else if ("cancelled".equals(status)) {
                    title = "预约已取消";
                    content = "您的预约已被取消。";
                } else if ("completed".equals(status)) {
                    title = "就诊完成";
                    content = "您的就诊已完成,感谢您的光临。";
                }

                if (!title.isEmpty()) {
                    sendAppointmentMessage(appointment.getUserId(), title, content, "appointment");
                }
            }
        }

        response.sendRedirect(request.getContextPath() + "/appointment?action=list");
    }

    private void deleteAppointment(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idStr = request.getParameter("id");

        if (idStr != null) {
            Integer id = Integer.parseInt(idStr);
            appointmentDAO.delete(id);
        }

        response.sendRedirect(request.getContextPath() + "/appointment?action=list");
    }

    private void cancelAppointment(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idStr = request.getParameter("id");

        if (idStr != null) {
            Integer id = Integer.parseInt(idStr);
            Appointment appointment = appointmentDAO.findById(id);

            if (appointment != null && appointmentDAO.updateStatus(id, "cancelled")) {
                // 发送取消预约消息
                sendAppointmentMessage(appointment.getUserId(),
                        "预约已取消",
                        "您已成功取消预约。如需重新预约,请访问预约挂号页面。",
                        "appointment");
            }
        }

        response.sendRedirect(request.getContextPath() + "/appointment?action=list");
    }

    /**
     * 发送预约相关消息
     */
    private void sendAppointmentMessage(Integer userId, String title, String content, String type) {
        Message message = new Message();
        message.setUserId(userId);
        message.setTitle(title);
        message.setContent(content);
        message.setType(type);
        message.setIsRead(0);
        messageDAO.add(message);
    }
}
