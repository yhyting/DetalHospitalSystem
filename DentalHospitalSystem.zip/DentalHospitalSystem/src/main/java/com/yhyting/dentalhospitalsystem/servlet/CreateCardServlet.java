package com.yhyting.dentalhospitalsystem.servlet;

import com.yhyting.dentalhospitalsystem.dao.ValueCardDAO;
import com.yhyting.dentalhospitalsystem.entity.User;
import com.yhyting.dentalhospitalsystem.entity.ValueCard;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Random;

@WebServlet("/user/createCard")
public class CreateCardServlet extends HttpServlet {
    private ValueCardDAO cardDAO = new ValueCardDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        // 检查是否已有储值卡
        ValueCard existingCard = cardDAO.findByUserId(user.getId());
        if (existingCard != null) {
            response.sendRedirect(request.getContextPath() + "/user/valuecard.jsp?error=您已开通储值卡");
            return;
        }

        // 生成卡号
        String cardNumber = generateCardNumber();
        
        // 创建新卡
        ValueCard card = new ValueCard();
        card.setUserId(user.getId());
        card.setCardNumber(cardNumber);
        card.setBalance(BigDecimal.ZERO);
        card.setTotalRecharge(BigDecimal.ZERO);
        card.setStatus(1); // 正常状态
        
        if (cardDAO.create(card)) {
            response.sendRedirect(request.getContextPath() + "/user/valuecard.jsp?success=储值卡开通成功");
        } else {
            response.sendRedirect(request.getContextPath() + "/user/valuecard.jsp?error=开通失败，请稍后再试");
        }
    }
    
    /**
     * 生成16位卡号
     */
    private String generateCardNumber() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder("6217");
        for (int i = 0; i < 12; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }
}
