package com.yhyting.dentalhospitalsystem.servlet;

import com.yhyting.dentalhospitalsystem.dao.UserDAO;
import com.yhyting.dentalhospitalsystem.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/user/updateProfile")
public class UpdateProfileServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String realName = request.getParameter("realName");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");
        String idCard = request.getParameter("idCard");

        user.setRealName(realName);
        user.setPhone(phone);
        user.setEmail(email);
        user.setIdCard(idCard);

        if (userDAO.update(user)) {
            // 更新session中的用户信息
            session.setAttribute("user", user);
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?editSuccess=true");
        } else {
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?editError=true");
        }
    }
}
