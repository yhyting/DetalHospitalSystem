package com.yhyting.dentalhospitalsystem.dao;

import com.yhyting.dentalhospitalsystem.entity.Favorite;
import com.yhyting.dentalhospitalsystem.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FavoriteDAO {

    /**
     * 添加收藏
     */
    public boolean add(Integer userId, Integer doctorId) {
        // 先检查是否已收藏
        if (exists(userId, doctorId)) {
            return false;
        }
        
        String sql = "INSERT INTO favorites (user_id, doctor_id) VALUES (?, ?)";
        try {
            return DBUtil.executeUpdate(sql, userId, doctorId) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 取消收藏
     */
    public boolean remove(Integer userId, Integer doctorId) {
        String sql = "DELETE FROM favorites WHERE user_id = ? AND doctor_id = ?";
        try {
            return DBUtil.executeUpdate(sql, userId, doctorId) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 检查是否已收藏
     */
    public boolean exists(Integer userId, Integer doctorId) {
        String sql = "SELECT COUNT(*) FROM favorites WHERE user_id = ? AND doctor_id = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            pstmt.setInt(2, doctorId);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        
        return false;
    }

    /**
     * 查询用户的所有收藏
     */
    public List<Favorite> findByUserId(Integer userId) {
        List<Favorite> favorites = new ArrayList<>();
        String sql = "SELECT f.*, u.real_name as doctor_name, u.phone as doctor_phone, u.email as doctor_email " +
                     "FROM favorites f " +
                     "LEFT JOIN users u ON f.doctor_id = u.id " +
                     "WHERE f.user_id = ? ORDER BY f.created_at DESC";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtil.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                favorites.add(extractFavorite(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        
        return favorites;
    }

    /**
     * 从ResultSet提取Favorite对象
     */
    private Favorite extractFavorite(ResultSet rs) throws SQLException {
        Favorite favorite = new Favorite();
        favorite.setId(rs.getInt("id"));
        favorite.setUserId(rs.getInt("user_id"));
        favorite.setDoctorId(rs.getInt("doctor_id"));
        favorite.setCreatedAt(rs.getTimestamp("created_at"));
        favorite.setDoctorName(rs.getString("doctor_name"));
        favorite.setDoctorPhone(rs.getString("doctor_phone"));
        favorite.setDoctorEmail(rs.getString("doctor_email"));
        return favorite;
    }
}
