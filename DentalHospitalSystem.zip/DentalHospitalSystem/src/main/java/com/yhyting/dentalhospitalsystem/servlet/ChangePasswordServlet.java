package com.yhyting.dentalhospitalsystem.servlet;

import com.yhyting.dentalhospitalsystem.dao.UserDAO;
import com.yhyting.dentalhospitalsystem.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/user/changePassword")
public class ChangePasswordServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String oldPassword = request.getParameter("oldPassword");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");

        // 验证当前密码
        if (!user.getPassword().equals(oldPassword)) {
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?pwdError=当前密码错误");
            return;
        }

        // 验证新密码
        if (newPassword == null || newPassword.length() < 6) {
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?pwdError=新密码长度不能少于6位");
            return;
        }

        // 验证两次密码是否一致
        if (!newPassword.equals(confirmPassword)) {
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?pwdError=两次输入的密码不一致");
            return;
        }

        // 修改密码
        if (userDAO.updatePassword(user.getId(), newPassword)) {
            // 更新session中的密码
            user.setPassword(newPassword);
            session.setAttribute("user", user);
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?pwdSuccess=true");
        } else {
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?pwdError=密码修改失败");
        }
    }
}
