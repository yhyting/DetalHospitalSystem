package com.yhyting.dentalhospitalsystem.servlet;

import com.yhyting.dentalhospitalsystem.dao.MessageDAO;
import com.yhyting.dentalhospitalsystem.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/message")
public class MessageServlet extends HttpServlet {
    private MessageDAO messageDAO = new MessageDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        PrintWriter out = response.getWriter();

        if (user == null) {
            out.print("{\"success\":false,\"message\":\"未登录\"}");
            out.flush();
            return;
        }

        String action = request.getParameter("action");
        boolean success = false;
        String message = "";

        try {
            if ("markRead".equals(action)) {
                String messageIdStr = request.getParameter("messageId");
                if (messageIdStr != null && !messageIdStr.isEmpty()) {
                    Integer messageId = Integer.parseInt(messageIdStr);
                    success = messageDAO.markAsRead(messageId);
                    message = success ? "已标记为已读" : "操作失败";
                }

            } else if ("markAllRead".equals(action)) {
                success = messageDAO.markAllAsRead(user.getId());
                message = success ? "所有消息已标记为已读" : "操作失败";

            } else if ("delete".equals(action)) {
                String messageIdStr = request.getParameter("messageId");
                if (messageIdStr != null && !messageIdStr.isEmpty()) {
                    Integer messageId = Integer.parseInt(messageIdStr);
                    success = messageDAO.delete(messageId);
                    message = success ? "删除成功" : "删除失败";
                }
            } else {
                message = "未知操作";
            }
        } catch (Exception e) {
            e.printStackTrace();
            success = false;
            message = "操作失败:" + e.getMessage();
        }

        // 返回JSON响应
        out.print("{\"success\":" + success + ",\"message\":\"" + message + "\"}");
        out.flush();
    }
}