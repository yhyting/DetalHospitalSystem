package com.yhyting.dentalhospitalsystem.filter;

import com.yhyting.dentalhospitalsystem.entity.User;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter(urlPatterns = {"/user/*", "/admin/*", "/doctor/*"})
public class AuthFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) 
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession(false);

        String requestURI = httpRequest.getRequestURI();
        String contextPath = httpRequest.getContextPath();

        // 检查用户是否登录
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null) {
            // 未登录，跳转到登录页面
            httpResponse.sendRedirect(contextPath + "/login.jsp");
            return;
        }

        // 检查权限
        String role = user.getRole();
        
        if (requestURI.startsWith(contextPath + "/admin/") && !"admin".equals(role)) {
            httpResponse.sendRedirect(contextPath + "/user/dashboard.jsp");
            return;
        }
        
        if (requestURI.startsWith(contextPath + "/doctor/") && !"doctor".equals(role) && !"admin".equals(role)) {
            httpResponse.sendRedirect(contextPath + "/user/dashboard.jsp");
            return;
        }

        // 通过验证，继续处理请求
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
    }
}
